<?php

echo 'Registrado correctamente';

echo '<p align="center"><a href="VerUsuariosConFoto.php">Ver datos de la bases de datos</a></p>';

?> 