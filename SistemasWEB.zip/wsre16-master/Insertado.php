<?php
echo 'Insertado correctamente en la base de datos y en el xml';

echo '<p align="center"><a href="VerPreguntas.php">Ver preguntas de la bases de datos</a></p>';
echo '<p align="center"><a href="VerPreguntasXML.php">Ver preguntas del XML</a></p>';
?>